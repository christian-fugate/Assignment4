#1 insersion Sort
Put the numbers that you want in until you are done,
then input the "no" 
it will then print out the sorted list 

#2 
input all the branches (even the null ones) in this way
		1
               /  \	
	     none   2
	      /\    /\
	  none none 3 none 
which would be the same as having 
1
none
2 
none 
none 
3
none

And after finishing branch input, type Done to finish it. 
IT will then print out in this format:
in order: [1,3,2]
pre order:[1,2,3]
